<?php


class Config {
    const SMTP_HOST = 'sandbox.smtp.mailtrap.io';
    const SMTP_PORT = 2525;
    const SMTP_USER = '9553dc288620b2';
    const SMTP_PASSWORD = '65da9a68377087';
}
