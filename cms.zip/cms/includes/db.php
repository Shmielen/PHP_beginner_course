<?php
//this file will contain the connection to DB

$db['db_host'] = "localhost";  //4 parameters to connect DB
$db['db_user'] = "root";
$db['db_pass'] = "";
$db['db_name'] = "cms";

foreach($db as $key => $value) //loop through array to make each parameter CONSTANT
{
    define(strtoupper($key), $value);
}


//$connection = mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);     (this didnt work the way ot does in the cours)

$connection = mysqli_connect("localhost","root","","cms");

// if($connection)
// {
//     echo "We are Connected";
// }


?>